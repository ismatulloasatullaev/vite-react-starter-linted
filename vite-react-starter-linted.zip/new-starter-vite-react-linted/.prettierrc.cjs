module.exports = {
    tabWidth: 4,
    singleQuote: true,
    semi: false,
    trailingComma: 'es5',
    singleQuote: true,
    useTabs: false,
    bracketSpacing: true,
    jsxBracketSameLine: false,
    arrowParens: 'avoid'
}