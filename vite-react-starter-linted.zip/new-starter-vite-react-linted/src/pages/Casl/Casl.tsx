import CaslComponent from 'components/Casl'

const Casl = () => (
    <>
        <h1> Casl Page: </h1>
        <CaslComponent />
    </>
)

export default Casl
