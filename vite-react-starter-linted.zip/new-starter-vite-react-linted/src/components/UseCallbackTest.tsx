import { useMemo, useState } from 'react'

import Item from './Item'

const UseCallbackTest = () => {
    const [counter, setCounter] = useState(0)

    const [state, setState] = useState(false)

    const fn = () => {
        const t = counter * 2

        return t
    }
    const memoized = useMemo(fn, [counter])

    return (
        <>
            <Item value={`${memoized}`} />

            <button onClick={() => setCounter(counter + 1)}>+</button>

            <h1>{counter}</h1>

            {state}

            <button onClick={() => setState(!state)}>change bool state</button>
        </>
    )
}

export default UseCallbackTest
