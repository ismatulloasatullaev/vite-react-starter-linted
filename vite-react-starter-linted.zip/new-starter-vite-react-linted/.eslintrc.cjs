module.exports = {
    root: true,
    env: { browser: true, es2020: true, es2021: true },
    extends: [
        'eslint:recommended',
        'plugin:@typescript-eslint/recommended',
        'plugin:prettier/recommended',
        'plugin:react-hooks/recommended',
        'plugin:react/recommended',
        'plugin:react/jsx-runtime',
        'prettier',
    ],
    ignorePatterns: ['dist', '.eslintrc.cjs'],
    parser: '@typescript-eslint/parser',
    plugins: [
        'react',
        'react-refresh',
        '@typescript-eslint',
        'prettier',
        'unused-imports',
        'simple-import-sort',
        'import',
    ],

    overrides: [
        {
            env: {
                node: true,
            },
            files: ['.eslintrc.{js,cjs}'],
            parserOptions: {
                sourceType: 'script',
            },
        },
    ],
    parserOptions: {
        ecmaVersion: 'latest',
        sourceType: 'module',
    },

    settings: {
        react: {
            version: 'detect', // Automatically includes the React version
        },
    },
    rules: {
        'import/no-cycle': 'off',
        'jsx-a11y/control-has-associated-label': 'off',
        'react/button-has-type': 'off',
        '@typescript-eslint/naming-convention': 'off',
        'class-methods-use-this': 'off',
        'no-param-reassign': 'off',
        '@typescript-eslint/no-explicit-any': 'off',
        'jsx-a11y/no-static-element-interactions': 'off',
        '@typescript-eslint/no-shadow': 'off',
        'no-return-assign': 'off',
        'no-debugger': 'off',
        'global-require': 'off',
        'react/jsx-uses-react': 'off',
        'react/react-in-jsx-scope': 'off',
        'jsx-a11y/click-events-have-key-events': 'off',
        'arrow-body-style': ['error', 'as-needed'],
        'newline-after-var': 'error',
        'no-unused-vars': 'off',
        '@typescript-eslint/no-unused-vars': 'off',
        'simple-import-sort/exports': 'error',
        'simple-import-sort/imports': [
            'error',
            {
                groups: [
                    // Side effect imports.
                    ['^\\u0000'],
                    // react
                    // Packages.
                    // Things that start with a letter (or digit or underscore), or `@` followed by a letter.
                    [
                        '^react$',
                        '^react-dom$',
                        '^react-router$',
                        '^react-router-dom$',
                        '^@?\\w',
                    ],
                    // Config import
                    ['^config'],
                    ['^store'],
                    // Absolute imports and Relative imports.
                    ['^services(/.*|$)'],
                    ['^helpers(/.*|$)'],
                    ['^modules(/.*|$)'],
                    ['^containers(/.*|$)'],
                    ['^layouts(/.*|$)'],
                    ['^pages(/.*|$)'],
                    ['^components(/.*|$)'],
                    ['^translations(/.*|$)'],
                    ['^assets(/.*|$)'],
                    // Parent imports. Put `..` last.
                    ['^\\.\\.(?!/?$)', '^\\.\\./?$'],
                    // Other relative imports. Put same-folder imports and `.` last.
                    ['^\\./(?=.*/)(?!/?$)', '^\\.(?!/?$)', '^\\./?$'],
                    // images imports
                    ['^.+\\.(svg|jpg|png)$'],
                    // Style imports.
                    ['^.+\\.s?css$'],
                    ['^'],
                ],
            },
        ],
        'import/first': 'error',
        'import/newline-after-import': 'error',
        'import/no-duplicates': 'error',
        'unused-imports/no-unused-imports': 'error',
        'object-curly-spacing': ['warn', 'always'],
        'max-len': [
            'warn',
            {
                code: 120,
                ignoreStrings: true,
                ignoreTemplateLiterals: true,
                ignoreComments: true,
            },
        ],
        'no-plusplus': [
            'error',
            {
                allowForLoopAfterthoughts: true,
            },
        ],
        'react/jsx-key': 'error',
        'react/jsx-props-no-spreading': 'off',
        'import/prefer-default-export': 'off',
        'react/jsx-boolean-value': 'off',
        'react/prop-types': 'off',
        'react/no-unescaped-entities': 'off',
        'react/jsx-one-expression-per-line': 'off',
        'react/jsx-wrap-multilines': 'off',
        'react/destructuring-assignment': 'off',
        '@typescript-eslint/comma-dangle': [
            'error',
            {
                arrays: 'only-multiline',
                objects: 'only-multiline',
                imports: 'only-multiline',
                exports: 'only-multiline',
                functions: 'never',
            },
        ],
    },
}
